# Footforall Documentation v2

## Structure

- product/ — vision, philosophy, business rules
- architecture/ — architecture and domain principles
- database/ — database conventions and physical model
- domains/ — domain-specific documentation
- engines/ — business engines
- api/ — API documentation
- adr/ — Architecture Decision Records
- archive/ — documents requiring review or consolidation

This reorganization is an architectural proposal generated from the existing repository.
Some documents may still require manual consolidation where duplicate content exists.
